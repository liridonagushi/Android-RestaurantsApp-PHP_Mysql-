<?php

     if(isset($_POST['searchQuery']))
     {
     	  require_once('config.inc.php');
	  	  $search_query=$_POST['searchQuery'];

          $sql = $connection->query('SELECT DISTINCT products.id_product, categories.category_name, products.product_name, products.sold_price, tablet_orders.id_staff, tablet_orders.qty FROM products LEFT JOIN categories ON products.id_category=categories.id_category LEFT JOIN tablet_orders ON products.id_product=tablet_orders.id_product WHERE products.product_name LIKE "%'.$search_query.'%" OR categories.category_name LIKE "%'.$search_query.'%"');

          if($sql->rowCount())
          {
		    $row_all = $sql->fetchall(PDO::FETCH_ASSOC);
			    header('Content-type: application/json');
		   	    echo json_encode($row_all);
          }

          elseif(!$sql->rowCount())
          {
	    	echo "no rows";
          }
     }
?>