<?php
          require_once('config.inc.php');

          $sql = $connection->exec('INSERT INTO tablet_orders(id_product, id_staff, qty)VALUES("1","1","1")');

          $insertId = $connection->lastInsertId();

          if($insertId>0){
              echo "Inserted new product";
          }
          else
          {
          echo "Not inserted";
          }
?>