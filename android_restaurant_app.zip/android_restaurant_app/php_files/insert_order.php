<?php
          require_once('config.inc.php');

          $sql = $connection->exec('INSERT INTO tablet_orders(id_product, id_staff, qty, product_details)VALUES("'.$_POST['id_product'].'","1","1","'.$_POST['product_details'].'")');

          $insertId = $connection->lastInsertId();

          if($insertId>0){
              echo "Inserted new product";
          }
          else
          {
          echo "Not inserted";
          }
?>