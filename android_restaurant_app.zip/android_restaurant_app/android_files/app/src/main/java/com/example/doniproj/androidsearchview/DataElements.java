package com.example.doniproj.androidsearchview;

/**
 * Created by doniProj on 13/05/2017.
 */

public class DataElements {
    public String idProd;
    public String prodName;
    public String catName;
    public String qtyIns;
    public int price;
}
