package com.example.doniproj.androidsearchview;

/**
 * Created by doniProj on 18/05/2017.
 */
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import android.content.Context;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StreamCorruptedException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by doniProj on 19/04/2017.
 */

public class BackgroundWorker extends AppCompatActivity {

public Context context;
    String value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, MainSearchView.class);
        startActivity(intent);

        Intent iin= getIntent();
        Bundle b = iin.getExtras();

        // String value = intent.getStringExtra("key");
        Toast.makeText(BackgroundWorker.this, "Intented value: " + b.get("idProd") + "" + b.get("idProd2"), Toast.LENGTH_SHORT).show();
    }
}

