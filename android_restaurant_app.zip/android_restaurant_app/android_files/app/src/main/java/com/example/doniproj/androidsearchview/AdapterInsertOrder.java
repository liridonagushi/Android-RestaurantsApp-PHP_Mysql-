package com.example.doniproj.androidsearchview;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StreamCorruptedException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by doniProj on 17/05/2017.
 */


public class AdapterInsertOrder extends AsyncTask<URL, Integer, String> {

    protected String doInBackground(URL... urls) {

        String result = null;
        String demoIdUrl=null;
        int resCode, error;
        InputStream in;
        try {
            URL url = new URL(demoIdUrl);
            HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();

            urlConn.setAllowUserInteraction(false);
            urlConn.setInstanceFollowRedirects(true);
            urlConn.setRequestMethod("POST");
            urlConn.connect();
            resCode = urlConn.getResponseCode();

            if (resCode == HttpURLConnection.HTTP_OK) {
                in = urlConn.getInputStream();

                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        in, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                String line;
                if ((line = reader.readLine()) != null) {
                    sb.append(line).append("\n");
                }
                in.close();
                result = sb.toString();
            } else {
                error = resCode;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    }


