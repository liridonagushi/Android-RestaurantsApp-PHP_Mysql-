package com.example.doniproj.androidsearchview;

/**
 * Created by doniProj on 13/05/2017.
 */

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.List;

public class AdapterElements extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static String idProduct;
    public Context context;
    public LayoutInflater inflater;
    List<DataElements> data= Collections.emptyList();
    DataElements current;
    public TextView insPlus;
    private Boolean rowDone;
    HttpURLConnection conn;
    URL url = null;
    String searchQuery;

    // create constructor to initialize context and data sent from MainActivity
    public AdapterElements(Context context, List<DataElements> data){
        this.context=context;
        inflater= LayoutInflater.from(context);
        this.data=data;
    }

    // Inflate the layout when ViewHolder created
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=inflater.inflate(R.layout.container_menu, parent,false);

        MyHolder holder=new MyHolder(view);
        return holder;
    }

    // Bind data
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        // Get current position of item in RecyclerView to bind data and assign values from list
        MyHolder myHolder= (MyHolder) holder;
        DataElements current=data.get(position);
        myHolder.textProdId.setText(current.idProd);
        myHolder.textProductName.setText(current.prodName);
        myHolder.textCategory.setText("Category: " + current.catName);
        myHolder.textQty.setText(current.qtyIns);
        myHolder.textPrice.setText("Price. " + current.price);
        myHolder.textPrice.setTextColor(ContextCompat.getColor(context, R.color.colorAccent));
    }

    // return total item from List
    @Override
    public int getItemCount() {
        return data.size();
    }

    class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView textProdId;
        TextView textProductName;
        TextView textCategory;
        TextView textPrice;
        TextView textQty;

        // create constructor to get widget reference
        public MyHolder(View itemView) {
            super(itemView);
            textProdId= (TextView) itemView.findViewById(R.id.textProdId);
            textProductName= (TextView) itemView.findViewById(R.id.textProductName);
            textCategory = (TextView) itemView.findViewById(R.id.textCategory);
            textQty = (TextView) itemView.findViewById(R.id.textQty);
            textPrice = (TextView) itemView.findViewById(R.id.textPrice);
            //itemView.setOnClickListener(this);

            TextView myButtonPlus = (TextView) itemView.findViewById(R.id.insPlus);
            myButtonPlus.setOnClickListener(this);

            TextView myButtonMinus = (TextView) itemView.findViewById(R.id.insMinus);
            myButtonMinus.setOnClickListener(this);
        }

        // Click event for all items
        @Override
            public void onClick(final View v) {

            TextView vg=(TextView)v;
            if(v.getId() == R.id.insPlus){

                String type="register";
                String username="insert";
                String password="insert";
            //    BackgroundWorker backgroundWorker = new BackgroundWorker(this);
            //    backgroundWorker.execute(type, username, password);

//                Intent intent = new Intent(v.getContext(), BackgroundWorker.class);
  //              intent.putExtra("value", 1);


                Intent Intent = new Intent(v.getContext(), BackgroundWorker.class);
                String strName = null;
                //idProduct=textProdId.getText().toString();

                Intent.putExtra("idProd", textProdId.getText().toString());
                Intent.putExtra("idProd2", textQty.getText());

                //   Intent.putExtra("id_product", textProdId.getText().toString());

                v.getContext().startActivity(Intent);


                // Toast.makeText(v.getContext(), "Inserted: " + textProdId.getText(), Toast.LENGTH_SHORT).show();

                //  AdapterInsertOrder adapterInsertOrder = new AdapterInsertOrder();
                //adapterInsertOrder.execute();
                //idProduct=textProdId.getText().toString();

              //  Toast.makeText(context, "Inserted " + vg.getText() + "id_product: " + idProduct, Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(context, "You clicked -1" + vg.getText(), Toast.LENGTH_SHORT).show();
            }
//            if (v.getId() == insPlus.getId()) {
//Toast.makeText(context, "You clicked button" + vg.getText() + " apart " + getAdapterPosition(), Toast.LENGTH_SHORT).show();
//            }else{
//                Toast.makeText(context, "You clicked an item" + textProdId.getText(), Toast.LENGTH_SHORT).show();
//            }
        }
    }
}
